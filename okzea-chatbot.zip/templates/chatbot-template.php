<html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>okzea Chatbot</title>
    <script src="/wp-content/plugins/okzea-chatbot/dist/js/okzea-chatbot.min.js"></script>
  </head> 
  <body>
    <div id="okzea-chatbot-wrapper">
      <okzea-chatbot></okzea-chatbot>
    </div>
  </body>
</html>
